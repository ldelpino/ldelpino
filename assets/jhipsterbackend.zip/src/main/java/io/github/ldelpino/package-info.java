/**
 * Application root.
 */
package io.github.ldelpino;
