/**
 * Application management.
 */
package io.github.ldelpino.management;
