/**
 * Data transfer objects for rest mapping.
 */
package io.github.ldelpino.service.dto;
