import { IUser } from './user.model';

export const sampleWithRequiredData: IUser = {
  id: 7659,
  login: 'foY!TN@u9\\0Zto-\\~KhM3p\\03kui1\\seK\\[Is3G',
};

export const sampleWithPartialData: IUser = {
  id: 26232,
  login: 'N6KMg',
};

export const sampleWithFullData: IUser = {
  id: 31728,
  login: 'C5g',
};
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
