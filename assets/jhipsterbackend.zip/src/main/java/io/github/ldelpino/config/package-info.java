/**
 * Application configuration.
 */
package io.github.ldelpino.config;
