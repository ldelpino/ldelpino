/**
 * Domain objects.
 */
package io.github.ldelpino.domain;
