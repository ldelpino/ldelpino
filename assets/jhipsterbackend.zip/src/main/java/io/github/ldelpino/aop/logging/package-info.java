/**
 * Logging aspect.
 */
package io.github.ldelpino.aop.logging;
