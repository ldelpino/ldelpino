/**
 * Repository layer.
 */
package io.github.ldelpino.repository;
