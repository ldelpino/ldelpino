/**
 * Rest layer error handling.
 */
package io.github.ldelpino.web.rest.errors;
