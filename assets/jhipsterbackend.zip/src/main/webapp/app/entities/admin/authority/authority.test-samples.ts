import { IAuthority, NewAuthority } from './authority.model';

export const sampleWithRequiredData: IAuthority = {
  name: 'c90bc786-7ea4-4c3b-8786-d3b3e62c8cec',
};

export const sampleWithPartialData: IAuthority = {
  name: 'b8952547-92a5-403c-b107-df6fc267f19e',
};

export const sampleWithFullData: IAuthority = {
  name: 'd53d5755-b286-4e6e-b389-d3f67f746736',
};

export const sampleWithNewData: NewAuthority = {
  name: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
