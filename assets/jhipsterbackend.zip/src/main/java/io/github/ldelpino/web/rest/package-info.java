/**
 * Rest layer.
 */
package io.github.ldelpino.web.rest;
