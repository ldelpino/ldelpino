/**
 * Application security utilities.
 */
package io.github.ldelpino.security;
