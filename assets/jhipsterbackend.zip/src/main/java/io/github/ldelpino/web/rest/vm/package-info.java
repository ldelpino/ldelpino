/**
 * Rest layer visual models.
 */
package io.github.ldelpino.web.rest.vm;
